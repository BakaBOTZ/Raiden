### 乂  Readme

BACA READMENYA PILIH "ID" BIAR GK BANYAK NANYA DI WA (GANGGU BNGST)

Language :  [EN](https://github.com/neoxr/neoxr-bot/blob/master/EN.md) | [ID](https://github.com/neoxr/neoxr-bot/blob/master/ID.md) 

### 乂  Documentation

You can see the documentation for using the messaging function [Here](https://github.com/neoxr/neoxr-bot/blob/master/DOCS.md).

### 乂  License
Copyright (c) 2022 Neoxr . Licensed under the [GNU GPLv3](https://github.com/neoxr/neoxr-bot/blob/master/LICENSE)